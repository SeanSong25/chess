#include "TextModifier.h"
using namespace std;
using namespace TextColour;

Modifier::Modifier(Code pCode) : code(pCode) {}
