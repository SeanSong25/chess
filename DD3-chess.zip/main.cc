#include "Game.h"

int main() {
    Game chessGame{};
    chessGame.play();
}
